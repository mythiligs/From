package com.test.Collections;

import java.text.DateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.swing.text.DateFormatter;

import com.test.annotation.FieldLength;



public record Customer(
		@FieldLength(length=5)int customerId,
		@FieldLength(length=10)String customerName,
		@FieldLength(length=10)String customerUsername,
		@FieldLength(length=10)LocalDate cust_dob,
		@FieldLength(length=10)String customerEmail,
		@FieldLength(length=10)String customerContactNumber,
		@FieldLength(length=10)String customerAlternateNumber,
		@FieldLength(length=10)String customerMailingAddress,
		@FieldLength(length=10)String customerPermanentAddress,
		@FieldLength(length=10)String customerNationality,
		@FieldLength(length=10)String customerNominee,
		@FieldLength(length=10)String customerMMID,
		@FieldLength(length=10)String customerAadhar,
		@FieldLength(length=10)String customerPANNumber,
		@FieldLength(length=10)String customerAccount
) 	
{
}
