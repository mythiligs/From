package com.test.Collections;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


import com.test.annotation.*;

public record Transaction
		(
				String TransactionId,
		@FieldLength(length = 20) String timestamp,
		@FieldLength(length = 30) Double TransactionWithdrawalAmount,
		@FieldLength(length = 20) Double TransactionDepositAmount,
		@FieldLength(length = 30) int Payer,
		@FieldLength(length = 20) int Payee,
		@FieldLength(length = 30) String TransactionType,
		@FieldLength(length = 20) String TransactionReferenceNumber,
		@FieldLength(length = 30) Double TransactionClosingAmount,
		@FieldLength(length = 20) String TransactionStatus
		) 
{
}
